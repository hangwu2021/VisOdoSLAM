#ifndef CONSTS_H_
#define CONSTS_H_

#include <iostream>
#include <vector>
#include <string>
#include <thread>
#include <chrono>
#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/persistence.hpp>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#define WIDTH 1280
#define HEIGHT 960

const int numCamera = 4;
const double PI = 3.1415926;
const cv::Size photoSize(1280, 960);
const cv::Size stitchResultSize(1200, 500);
const double disFloorToCenter = 0.005;

//物理世界坐标与OpenGL坐标的比例，单位:mm
//这里含义是：OpenGL坐标中单位1表示物理世界中的10000mm(10m)
const double scale = 3000.0; 
const int region_num = 8;
//前、左、后、右四个棋盘格世界坐标系原点在OpenGL世界坐标系中的坐标, OpenGL世界坐标系的原点定在盲区中心
const double z_origin_front = -100;//OpenGL坐标系中的坐标没有物理单位？这里世界坐标系原点的坐标暂时以mm为单位
const double x_origin_front = 1100;
const double y_origin_front = 0.0;
const double z_origin_left = -700;
const double x_origin_left = -100;
const double y_origin_left = 0.0;
const double z_origin_back = 100;
const double x_origin_back = -1100;
const double y_origin_back = 0.0;
const double z_origin_right = 700;
const double x_origin_right = 100;
const double y_origin_right = 0.0;

//盲区A、B、C、D四个点在OpenGL世界坐标系中的坐标
const double x_A = 300;
const double z_A = -200;
const double y_A = 0.0;
const double x_B = 300;
const double z_B = 200;
const double y_B = 0.0;
const double x_C = -300;
const double z_C = -200;
const double y_C = 0.0;
const double x_D = -300;
const double z_D = 200;
const double y_D = 0.0;

#endif // CONSTS_H_
