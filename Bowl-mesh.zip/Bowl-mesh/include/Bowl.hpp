#pragma once

#include <stdint.h>
#include <limits>
#include <vector>
#include <cmath>

#include <glm/glm.hpp>

#include "Consts.hpp"
#include "meshgrid.hpp"

using uint = uint32_t;
using int32 = int32_t;

enum class Region { A, B, C, D, E, F, G, H };

class Bowl
{
private:
	constexpr static float def_cen[3]{ 0.0f }; // for default value pass to constructor - argument center 
	constexpr static float PI = 3.14159265359f;
	constexpr static auto epsilon = std::numeric_limits<float>::epsilon();
	constexpr static int32 _num_vertices = 3; // x, y, z

private:
	float cen[3];
	float inner_rad;
	float rad;
	float param_a, param_b, param_c;
	float hole_rad;
	bool set_hole = false;
	bool useUV = false;
	float polar_coord = 2 * PI;

	std::vector<int> num_vertice_A;
	std::vector<int> num_vertice_B;
	std::vector<int> num_vertice_C;
	std::vector<int> num_vertice_D;
	std::vector<int> num_vertice_E;
	std::vector<int> num_vertice_F;
	std::vector<int> num_vertice_G;
	std::vector<int> num_vertice_H;
	std::vector<std::vector<int>> num_vertices;

public:
	Bowl(const float inner_radius, const float radius, const float a, const float b, const float c, const float center[3] = def_cen)
		: inner_rad(inner_radius), rad(radius), param_a(a), param_b(b), param_c(c), hole_rad(0.f)
	{
		cen[0] = center[0];
		cen[1] = center[1];
		cen[2] = center[2];
	}

	bool generate_mesh(const float max_size_vert, std::vector<float>& vertices, std::vector<uint>& indices)
	{
		set_hole = false;
		useUV = false;
		polar_coord = 2 * PI;
		return generate_mesh_(max_size_vert, vertices, indices);
	}

	bool generate_mesh_uv(const float max_size_vert, std::vector<float>& vertices, std::vector<uint>& indices)
	{
		set_hole = false;
		useUV = true;
		polar_coord = 2 * PI;
		return generate_mesh_(max_size_vert, vertices, indices);
	}

	bool generate_mesh_uv_part(const float part_polar, const float max_size_vert, std::vector<float>& vertices, std::vector<uint>& indices)
	{
		set_hole = false;
		useUV = true;
		polar_coord = part_polar;
		return generate_mesh_(max_size_vert, vertices, indices);
	}

	bool generate_mesh_hole(const float max_size_vert, const float hole_radius, std::vector<float>& vertices, std::vector<uint>& indices)
	{
		set_hole = true;
		useUV = false;
		hole_rad = hole_radius;
		polar_coord = 2 * PI;
		return generate_mesh_(max_size_vert, vertices, indices);
	}

	bool generate_mesh_hole_part(const float part_polar, const float max_size_vert, const float hole_radius, std::vector<float>& vertices, std::vector<uint>& indices)
	{
		set_hole = true;
		useUV = false;
		hole_rad = hole_radius;
		polar_coord = part_polar;
		return generate_mesh_(max_size_vert, vertices, indices);
	}

	bool generate_mesh_uv_hole(const float max_size_vert, const float hole_radius, std::vector<float>& vertices, std::vector<uint>& indices)
	{
		set_hole = true;
		useUV = true;
		hole_rad = hole_radius;
		polar_coord = 2 * PI;
		return generate_mesh_(max_size_vert, vertices, indices);
	}

	bool generate_mesh_uv_hole_part(const float part_polar, const float max_size_vert, const float hole_radius, std::vector<float>& vertices, std::vector<uint>& indices)
	{
		set_hole = true;
		useUV = true;
		hole_rad = hole_radius;
		polar_coord = part_polar;
		return generate_mesh_(max_size_vert, vertices, indices);
	}

// protected:
public:
	bool generate_mesh_(const float max_size_vert, std::vector<float>& vertices, std::vector<uint>& indices)
	{
		if (fabs(param_a) <= epsilon || fabs(param_b) <= epsilon || fabs(param_c) <= epsilon)
			return false;
		if (rad <= 0.f || inner_rad <= 0.f)
			return false;
		if (set_hole && hole_rad <= 0.f)
			return false;
		
		auto a = param_a;
		auto b = param_b;
		auto c = param_c;
		
		vertices.clear();
		indices.clear();

		/*
			prepare grid mesh in polar coordinate with r - radius and theta - angle
		*/
		// texture coordinates generate (u, v) [0, 1]
		std::vector<float> texture_u = meshgen::linspace(0.0f, 1.f, max_size_vert);
		auto texture_v = texture_u;

		auto r = meshgen::linspace(0.0f, rad, max_size_vert); // min_size = 0.f, max_size = 100.f, 
		auto theta = meshgen::linspace(0.f, polar_coord, max_size_vert);
		auto mesh_pair = meshgen::meshgrid(r, theta);

		auto R = std::get<0>(mesh_pair);
		auto THETA = std::get<1>(mesh_pair);
		size_t grid_size = R.size();
		std::vector<float> x_grid;
		std::vector<float> y_grid;
		std::vector<float> z_grid;

		// Convert to rectangular coordinates
		// x = r*cos(theta), z = r*sin(theta), y/c = (x^2)/(a^2) + (z^2)/(b^2); 
		for (int i = 0; i < grid_size; ++i) {
			for (int j = 0; j < grid_size; ++j) {
				auto x = R(i, j) * cos(THETA(i, j));
				auto z = R(i, j) * sin(THETA(i, j));
				auto y = c * (pow((x / a), 2) + pow((z / b), 2));
				x_grid.push_back(x);
				z_grid.push_back(z);
				y_grid.push_back(y);
			}
		}

		/*
			find start level - level when disk passes from to elliptic paraboloid
		*/
		auto min_y = 0.f;
		auto idx_min_y = 0u; // index y - component when transition between disk and paraboloid
		for (int i = 0; i < grid_size; ++i) {
			for (int j = 0; j < grid_size; ++j) {
				auto x = x_grid[j + i * grid_size];
				auto z = z_grid[j + i * grid_size];
				if (lt_radius(x, z, inner_rad)) { // check level of paraboloid
					min_y = y_grid[j + i * grid_size];
					idx_min_y = i;
					break;
				}
			}
		}

		/*
			generate mesh vertices for disk and elliptic paraboloid
		*/
		auto vertices_size = 0;
		auto half_grid = grid_size / 2;
		auto offset_idx_min_y = 0;
		for (int i = 0; i < grid_size; ++i) {
			for (int j = 0; j < grid_size; ++j) {
				auto x = x_grid[j + i * grid_size];
				auto z = z_grid[j + i * grid_size];

				if (set_hole) { // check hole inside disk
					auto skip = lt_radius(x, z, hole_rad);
					if (skip) {
						offset_idx_min_y = i + 1;
						continue;
					}
				}

				auto y = min_y;
				if (gt_radius(x, z, inner_rad)) // check level of paraboloid
					y = y_grid[j + i * grid_size];

				vertices.push_back(x + cen[0]);
				vertices.push_back(y + cen[1]);
				vertices.push_back(z + cen[2]);
				vertices_size += 3;

				if (useUV) { // texture coordinates
					auto u = texture_u[j];
					auto v = texture_v[i];
					if (j == 0 && i == 0 && !set_hole)
						u = texture_u[half_grid];
					vertices.push_back(u);
					vertices.push_back(v);
				}
			}
		}

		/*
			generate indices by y-order
		*/
		if (set_hole) 
			idx_min_y -= offset_idx_min_y;

		auto last_vert = vertices_size / 3;
		generate_indices(indices, grid_size, idx_min_y, last_vert);
		
		return true;
	}

	// Matrix to Vector 
	cv::Vec3d Matx31d2Vec3d(cv::Matx31d m)
	{
		cv::Vec3d v;
		v(0) = m(0,0);
		v(1) = m(1,0);
		v(2) = m(2,0);
		return v;
	}

	// Generate 8 Region for Texture Mapping
	bool generate_mesh_test_(const float max_size_vert, const float hole_radius, std::vector<std::vector<float>>& vertices, std::vector<std::vector<uint>>& indices) 
	{
		// Camera Intrisics 
		cv::FileStorage fs_read_front("param/front.yaml", cv::FileStorage::READ);
		cv::FileStorage fs_read_back("param/back.yaml", cv::FileStorage::READ);
		cv::FileStorage fs_read_left("param/left.yaml", cv::FileStorage::READ);
		cv::FileStorage fs_read_right("param/right.yaml", cv::FileStorage::READ);
		cv::Mat intrinsic_matrix_front,intrinsic_matrix_back,intrinsic_matrix_left,intrinsic_matrix_right;
		cv::Mat distortion_coeffs_front,distortion_coeffs_back,distortion_coeffs_left,distortion_coeffs_right;
		cv::Mat rotMat_front,rotMat_back,rotMat_left,rotMat_right;
		cv::Mat tvec_front,tvec_back,tvec_left,tvec_right;

		// Vec3d tvec_front,tvec_back;
		fs_read_front["camera_matrix"] >> intrinsic_matrix_front;
		fs_read_front["dist_coeffs"] >> distortion_coeffs_front;
		fs_read_front["rotMat_front"] >> rotMat_front;
		fs_read_front["tvec_front"] >> tvec_front;

		fs_read_back["camera_matrix"] >> intrinsic_matrix_back;
		fs_read_back["dist_coeffs"] >> distortion_coeffs_back;
		fs_read_back["rotMat_back"] >> rotMat_back;
		fs_read_back["tvec_back"] >> tvec_back;

		fs_read_left["camera_matrix"] >> intrinsic_matrix_left;
		fs_read_left["dist_coeffs"] >> distortion_coeffs_left;
		fs_read_left["rotMat_left"] >> rotMat_left;
		fs_read_left["tvec_left"] >> tvec_left;

		fs_read_right["camera_matrix"] >> intrinsic_matrix_right;
		fs_read_right["dist_coeffs"] >> distortion_coeffs_right;
		fs_read_right["rotMat_right"] >> rotMat_right;
		fs_read_right["tvec_right"] >> tvec_right;

		// 椭圆抛物面
		hole_rad = hole_radius;
		if (fabs(param_a) <= epsilon || fabs(param_b) <= epsilon || fabs(param_c) <= epsilon) {
			return false;
		}

		if (rad <= 0.f || inner_rad <= 0.f) {
			return false;
		}

		if (hole_rad < 0.f) {
			return false;
		}

		auto a = param_a;
		auto b = param_b;
		auto c = param_c;

		vertices = std::move(std::vector<std::vector<float>>(region_num));
		indices = std::move(std::vector<std::vector<uint>>(region_num));

		vertices.clear();
		indices.clear();

		//生成世界坐标系下的碗模型顶点(OpenGL坐标系下坐标范围为-1～1，放大1000倍到世界坐标系下)
		auto r = meshgen::linspace(hole_rad, rad, max_size_vert); // min_size = 0.f, max_size = 100.f,
		auto theta = meshgen::linspace(0.f, polar_coord, max_size_vert);
		auto mesh_pair = meshgen::meshgrid(r, theta);
		auto R = std::get<0>(mesh_pair);
		auto THETA = std::get<1>(mesh_pair);
		size_t grid_size = R.size();
		std::vector<float> x_grid;	//OpenGL坐标系下的坐标
		std::vector<float> y_grid;
		std::vector<float> z_grid;

		std::vector<float> x_world;	//OpenGL世界坐标系下的坐标
		std::vector<float> y_world;
		std::vector<float> z_world;

		// Convert to rectangular coordinates
		// x = r*cos(theta), z = r*sin(theta), y/c = (x^2)/(a^2) + (z^2)/(b^2);
		for (int i = 0; i < grid_size; ++i) {	//外层循环改变R
			for (int j = 0; j < grid_size; ++j) {	//内层循环改变Theta
				auto Rij = R(i, j);
				auto Thetaij = THETA(i, j);
				auto x = R(i, j) * cos(THETA(i, j));
				auto z = R(i, j) * sin(THETA(i, j));
				auto y = c * (pow((x / a), 2) + pow((z / b), 2));
				x_grid.push_back(x);
				z_grid.push_back(z);
				y_grid.push_back(y);
				
				x_world.push_back(scale*x);
				y_world.push_back(scale*y);
				z_world.push_back(scale*z);
			}
		}

		/*
			find start level - level when disk passes from to elliptic paraboloid
        */
        auto min_y = 0.f;
        auto idx_min_y = 0u; // index y - component when transition between disk and paraboloid
        for (int i = 0; i < grid_size; ++i) {
			for (int j = 0; j < grid_size; ++j) {
				auto x = x_grid[j + i * grid_size];
				auto z = z_grid[j + i * grid_size];
				if (lt_radius(x, z, inner_rad)) { // check level of paraboloid, inner_rad:0.4
					min_y = y_grid[j + i * grid_size];      //碗状模型底部的垂向坐标
					idx_min_y = i;                          //碗状模型底部的垂向坐标索引
					break;
				}
			}
        }

		for (int i = 0; i < grid_size; ++i) {
			for (int j = 0; j < grid_size; ++j) {
				auto x = x_grid[j + i * grid_size];
				auto z = z_grid[j + i * grid_size];
				if (lt_radius(x, z, inner_rad)) // check level of paraboloid
				{
					y_grid[j + i * grid_size] = min_y;
					y_world[j + i * grid_size] = min_y*scale;
				}
			}
		}

		//根据盲区的范围，筛选出前、后、左、右(A\B\C\D)四个不重叠区域的顶点和重叠区域的顶点(E\F\G\H)
		std::vector<float> x_world_A;	//OpenGL世界坐标系下的A区顶点坐标
		std::vector<float> z_world_A;
		std::vector<float> y_world_A;
		std::vector<float> x_world_B;	//OpenGL坐标系下的B区顶点坐标
		std::vector<float> z_world_B;
		std::vector<float> y_world_B;
		std::vector<float> x_world_C;	//OpenGL坐标系下的C区顶点坐标
		std::vector<float> z_world_C;
		std::vector<float> y_world_C;
		std::vector<float> x_world_D;	//OpenGL坐标系下的D区顶点坐标
		std::vector<float> z_world_D;
		std::vector<float> y_world_D;
		std::vector<float> x_world_E;	//OpenGL坐标系下的E区顶点坐标
		std::vector<float> z_world_E;
		std::vector<float> y_world_E;
		std::vector<float> x_world_F;	//OpenGL坐标系下的F区顶点坐标
		std::vector<float> z_world_F;
		std::vector<float> y_world_F;
		std::vector<float> x_world_G;	//OpenGL坐标系下的G区顶点坐标
		std::vector<float> z_world_G;
		std::vector<float> y_world_G;
		std::vector<float> x_world_H;	//OpenGL坐标系下的H区顶点坐标
		std::vector<float> z_world_H;
		std::vector<float> y_world_H;

		for (int i = 0; i < grid_size; ++i) {
			int temp_A=0;
			int temp_B=0;
			int temp_C=0;
			int temp_D=0;
			int temp_E=0;
			int temp_F=0;
			int temp_G=0;
			int temp_H=0;
			for (int j = 0; j < grid_size; ++j) {
				auto x = x_world[j + i * grid_size];
				auto z = z_world[j + i * grid_size];
				auto y = y_world[j + i * grid_size];
				if(x > x_A && (z >= 1.1*z_A && z <= 1.1*z_B)) {
				// if(x > 0 && (z >= -800 && z <= 800)) {
					x_world_A.push_back(x);
					z_world_A.push_back(z);
					y_world_A.push_back(y);
					temp_A++;
				}

				if(x < x_C && (z >= 1.1*z_A && z <= 1.1*z_B)) {
					x_world_B.push_back(x);
					z_world_B.push_back(z);
					y_world_B.push_back(y);
					temp_B++;
				}

				if((x >= 1.1*x_C && x <= 1.1*x_A) && z < z_C) {
					x_world_C.push_back(x);
					z_world_C.push_back(z);
					y_world_C.push_back(y);
					temp_C++;
				}

				if((x >= 1.1*x_C && x <= 1.1*x_A) && z > z_D) {
					x_world_D.push_back(x);
					z_world_D.push_back(z);
					y_world_D.push_back(y);
					temp_D++;
				}

				if(x > x_A && z < z_A) {
					x_world_E.push_back(x);
					z_world_E.push_back(z);
					y_world_E.push_back(y);
					temp_E++;
				}

				if(x > x_B && z > z_B) {
					x_world_F.push_back(x);
					z_world_F.push_back(z);
					y_world_F.push_back(y);
					temp_F++;
				}

				if(x < x_C && z < z_C) {
					x_world_G.push_back(x);
					z_world_G.push_back(z);
					y_world_G.push_back(y);
					temp_G++;
				}

				if(x < x_D && z > z_D) {
					x_world_H.push_back(x);
					z_world_H.push_back(z);
					y_world_H.push_back(y);
					temp_H++;
				}
			}
			num_vertice_A.push_back(temp_A);
			num_vertice_B.push_back(temp_B);
			num_vertice_C.push_back(temp_C);
			num_vertice_D.push_back(temp_D);
			num_vertice_E.push_back(temp_E);
			num_vertice_F.push_back(temp_F);
			num_vertice_G.push_back(temp_G);
			num_vertice_H.push_back(temp_H);
			// std::cout<<"num of vert A is :"<<temp_A<<std::endl;
		}
		num_vertices.push_back(num_vertice_A);
		num_vertices.push_back(num_vertice_B);
		num_vertices.push_back(num_vertice_C);
		num_vertices.push_back(num_vertice_D);
		num_vertices.push_back(num_vertice_E);
		num_vertices.push_back(num_vertice_F);
		num_vertices.push_back(num_vertice_G);
		num_vertices.push_back(num_vertice_H);

		cv::Point3d global_point_front, global_point_back, global_point_left, global_point_right;
		cv::Point3d global_point_front_E, global_point_left_E;//global_point_front_E表示E区的点在前相机世界坐标系下的坐标，其他以此类推
		cv::Point3d global_point_front_F, global_point_right_F;
		cv::Point3d global_point_back_G, global_point_left_G;
		cv::Point3d global_point_back_H, global_point_right_H;
		int vertices_size[region_num] { 0 };
		auto offset_idx_min_y = 0;
		
		for(int i = 0; i < x_world_A.size(); i++) {
			global_point_front.x = z_world_A[i] - z_origin_front;
			global_point_front.y = x_origin_front - x_world_A[i];
			global_point_front.z = -(y_world_A[i] - scale*min_y);
			
			//求得像素并进行归一化
			// auto camera_point_front = rotMat_front * Vec3d(global_point_front) + tvec_front;
			// auto pointInPixelCoord = (1/camera_point_front(2)) * intrinsic_matrix_front * camera_point_front;
			// auto x = pointInPixelCoord(0);
			// auto y = pointInPixelCoord(1);

			std::vector<cv::Point2f> img_point_front;
			auto Affine = cv::Affine3d(rotMat_front, Matx31d2Vec3d(tvec_front));
    		cv::fisheye::projectPoints(std::vector<cv::Point3f>(1, cv::Point3d(global_point_front.x, global_point_front.y, global_point_front.z)), img_point_front, Affine, intrinsic_matrix_front, distortion_coeffs_front);
			auto x = img_point_front.front().x;
			auto y = img_point_front.front().y;

			auto u = x / WIDTH;
			auto v = (HEIGHT - y) / HEIGHT;
			// auto v = y / HEIGHT;
			vertices[0].push_back(x_world_A[i]/scale);
			vertices[0].push_back(y_world_A[i]/scale);
			vertices[0].push_back(z_world_A[i]/scale);
			vertices_size[0] += 3;
			vertices[0].push_back(u);
			vertices[0].push_back(v);
		}
		for(int i = 0; i < x_world_B.size(); i++) {
			global_point_back.x = z_origin_back-z_world_B[i];
			global_point_back.y = x_world_B[i]-x_origin_back;
			global_point_back.z = -(y_world_A[i] - scale*min_y);
			
			std::vector<cv::Point2f> img_point_back;
			auto Affine = cv::Affine3d(rotMat_back, Matx31d2Vec3d(tvec_back));
    		cv::fisheye::projectPoints(std::vector<cv::Point3f>(1, cv::Point3d(global_point_back.x, global_point_back.y, global_point_back.z)), img_point_back, Affine, intrinsic_matrix_back, distortion_coeffs_back);
			auto x = img_point_back.front().x;
			auto y = img_point_back.front().y;

			auto u = x / WIDTH;
			auto v = (HEIGHT - y) / HEIGHT;
			// auto v = y / HEIGHT;
			vertices[1].push_back(x_world_B[i]/scale);
			vertices[1].push_back(y_world_B[i]/scale);
			vertices[1].push_back(z_world_B[i]/scale);
			vertices_size[1] += 3;
			vertices[1].push_back(u);
			vertices[1].push_back(v);
		}
		for(int i = 0; i < x_world_C.size(); i++) {
			global_point_left.x = x_world_C[i]-x_origin_left;
			global_point_left.y = z_world_C[i]-z_origin_left;
			global_point_left.z = -(y_world_C[i] - scale*min_y);

			std::vector<cv::Point2f> img_point_left;
			auto Affine = cv::Affine3d(rotMat_left, Matx31d2Vec3d(tvec_left));
    		cv::fisheye::projectPoints(std::vector<cv::Point3f>(1, cv::Point3d(global_point_left.x, global_point_left.y, global_point_left.z)), img_point_left, Affine, intrinsic_matrix_left, distortion_coeffs_left);
			auto x = img_point_left.front().x;
			auto y = img_point_left.front().y;

			auto u = x / WIDTH;
			auto v = (HEIGHT-y) / HEIGHT;
			// auto v = y / HEIGHT;
			vertices[2].push_back(x_world_C[i]/scale);
			vertices[2].push_back(y_world_C[i]/scale);
			vertices[2].push_back(z_world_C[i]/scale);
			vertices_size[2] += 3;
			vertices[2].push_back(u);
			vertices[2].push_back(v);
		}
		for(int i = 0; i < x_world_D.size(); i++) {
			global_point_right.x = x_origin_right-x_world_D[i];
			global_point_right.y = z_origin_right-z_world_D[i];
			global_point_right.z = -(y_world_D[i] - scale*min_y);

			std::vector<cv::Point2f> img_point_right;
			auto Affine = cv::Affine3d(rotMat_right, Matx31d2Vec3d(tvec_right));
    		cv::fisheye::projectPoints(std::vector<cv::Point3f>(1, cv::Point3d(global_point_right.x, global_point_right.y, global_point_right.z)), img_point_right, Affine, intrinsic_matrix_right, distortion_coeffs_right);
			auto x = img_point_right.front().x;
			auto y = img_point_right.front().y;

			auto u = x / WIDTH;
			auto v = (HEIGHT-y) / HEIGHT;
			// auto v = y / HEIGHT;
			vertices[3].push_back(x_world_D[i]/scale);
			vertices[3].push_back(y_world_D[i]/scale);
			vertices[3].push_back(z_world_D[i]/scale);
			vertices_size[3] += 3;
			vertices[3].push_back(u);
			vertices[3].push_back(v);
		}
		for(int i = 0; i < x_world_E.size(); i++) {
			//front
			global_point_front_E.x = z_world_E[i]-z_origin_front;
			global_point_front_E.y = x_origin_front-x_world_E[i];
			global_point_front_E.z = -(y_world_E[i] - scale*min_y);
			std::vector<cv::Point2f> img_point_front_E;
			auto Affine = cv::Affine3d(rotMat_front, Matx31d2Vec3d(tvec_front));
    		cv::fisheye::projectPoints(std::vector<cv::Point3f>(1, cv::Point3d(global_point_front_E.x, global_point_front_E.y, global_point_front_E.z)), img_point_front_E, Affine, intrinsic_matrix_front, distortion_coeffs_front);
			auto x_front = img_point_front_E.front().x;
			auto y_front = img_point_front_E.front().y;
			auto u_front = x_front / WIDTH;
			auto v_front = (HEIGHT-y_front) / HEIGHT;
			vertices[4].push_back(x_world_E[i]/scale);
			vertices[4].push_back(y_world_E[i]/scale);
			vertices[4].push_back(z_world_E[i]/scale);
			vertices_size[4] += 3;
			vertices[4].push_back(u_front);
			vertices[4].push_back(v_front);

			//left
			global_point_left_E.x = x_world_E[i]-x_origin_left;
			global_point_left_E.y = z_world_E[i]-z_origin_left;
			global_point_left_E.z = -(y_world_E[i] - scale*min_y);
			std::vector<cv::Point2f> img_point_left_E;
			auto Affine2 = cv::Affine3d(rotMat_left, Matx31d2Vec3d(tvec_left));
    		cv::fisheye::projectPoints(std::vector<cv::Point3f>(1, cv::Point3d(global_point_left_E.x, global_point_left_E.y, global_point_left_E.z)), img_point_left_E, Affine2, intrinsic_matrix_left, distortion_coeffs_left);
			auto x_left = img_point_left_E.front().x;
			auto y_left = img_point_left_E.front().y;
			auto u_left = x_left / WIDTH;
			auto v_left = (HEIGHT-y_left) / HEIGHT;
			vertices[4].push_back(u_left);
			vertices[4].push_back(v_left);

			//融合weight
			float theta  =atan(abs((x_world_E[i]-x_A)/(z_world_E[i]-z_A)));
			float mixValue = 2*theta / PI;
			vertices[4].push_back(mixValue);
		}
		for(int i = 0; i < x_world_F.size(); i++) {
			//front
			global_point_front_F.x = z_world_F[i]-z_origin_front;
			global_point_front_F.y = x_origin_front-x_world_F[i];
			global_point_front_F.z = -(y_world_F[i] - scale*min_y);
			std::vector<cv::Point2f> img_point_front_F;
			auto Affine = cv::Affine3d(rotMat_front, Matx31d2Vec3d(tvec_front));
    		cv::fisheye::projectPoints(std::vector<cv::Point3f>(1, cv::Point3d(global_point_front_F.x, global_point_front_F.y, global_point_front_F.z)), img_point_front_F, Affine, intrinsic_matrix_front, distortion_coeffs_front);
			auto x_front = img_point_front_F.front().x;
			auto y_front = img_point_front_F.front().y;
			auto u_front = x_front / WIDTH;
			auto v_front = (HEIGHT-y_front) / HEIGHT;
			vertices[5].push_back(x_world_F[i]/scale);
			vertices[5].push_back(y_world_F[i]/scale);
			vertices[5].push_back(z_world_F[i]/scale);
			vertices_size[5] += 3;
			vertices[5].push_back(u_front);
			vertices[5].push_back(v_front);

			//right
			global_point_right_F.x = x_origin_right-x_world_F[i];
			global_point_right_F.y = z_origin_right-z_world_F[i];
			global_point_right_F.z = -(y_world_F[i] - scale*min_y);
			std::vector<cv::Point2f> img_point_right_F;
			auto Affine2 = cv::Affine3d(rotMat_right, Matx31d2Vec3d(tvec_right));
			cv::fisheye::projectPoints(std::vector<cv::Point3f>(1, cv::Point3d(global_point_right_F.x, global_point_right_F.y, global_point_right_F.z)), img_point_right_F, Affine2, intrinsic_matrix_right, distortion_coeffs_right);
			auto x_right = img_point_right_F.front().x;
			auto y_right = img_point_right_F.front().y;
			auto u_right = x_right / WIDTH;
			auto v_right = (HEIGHT-y_right) / HEIGHT;
			vertices[5].push_back(u_right);
			vertices[5].push_back(v_right);

			//融合weight
			float theta  =atan(abs((x_world_F[i]-x_B)/(z_world_F[i]-z_B)));
			float mixValue = 2*theta / PI;
			vertices[5].push_back(mixValue);
		}
		for(int i = 0; i < x_world_G.size(); i++) {
			//back
			global_point_back_G.x = z_origin_back-z_world_G[i];
			global_point_back_G.y = x_world_G[i]-x_origin_back;
			global_point_back_G.z = -(y_world_G[i] - scale*min_y);
			std::vector<cv::Point2f> img_point_back_G;
			auto Affine = cv::Affine3d(rotMat_back, Matx31d2Vec3d(tvec_back));
    		cv::fisheye::projectPoints(std::vector<cv::Point3f>(1, cv::Point3d(global_point_back_G.x, global_point_back_G.y, global_point_back_G.z)), img_point_back_G, Affine, intrinsic_matrix_back, distortion_coeffs_back);
			auto x_back = img_point_back_G.front().x;
			auto y_back = img_point_back_G.front().y;
			auto u_back = x_back / WIDTH;
			auto v_back = (HEIGHT-y_back) / HEIGHT;
			vertices[6].push_back(x_world_G[i]/scale);
			vertices[6].push_back(y_world_G[i]/scale);
			vertices[6].push_back(z_world_G[i]/scale);
			vertices_size[6] += 3;
			vertices[6].push_back(u_back);
			vertices[6].push_back(v_back);

			//left
			global_point_left_G.x = x_world_G[i]-x_origin_left;
			global_point_left_G.y = z_world_G[i]-z_origin_left;
			global_point_left_G.z = -(y_world_G[i] - scale*min_y); 
			std::vector<cv::Point2f> img_point_left_G;
			auto Affine2 = cv::Affine3d(rotMat_left, Matx31d2Vec3d(tvec_left));
    		cv::fisheye::projectPoints(std::vector<cv::Point3f>(1, cv::Point3d(global_point_left_G.x, global_point_left_G.y, global_point_left_G.z)), img_point_left_G, Affine2, intrinsic_matrix_left, distortion_coeffs_left);
			auto x_left = img_point_left_G.front().x;
			auto y_left = img_point_left_G.front().y;
			auto u_left = x_left / WIDTH;
			auto v_left = (HEIGHT-y_left) / HEIGHT;
			vertices[6].push_back(u_left);
			vertices[6].push_back(v_left);

			//融合weight
			float theta  =atan(abs((x_world_G[i]-x_C)/(z_world_G[i]-z_C)));
			float mixValue = 2*theta / PI;
			vertices[6].push_back(mixValue);
		}
		for(int i = 0; i < x_world_H.size(); i++) {
			//back
			global_point_back_H.x = z_origin_back-z_world_H[i];
			global_point_back_H.y = x_world_H[i]-x_origin_back;
			global_point_back_H.z = -(y_world_H[i] - scale*min_y);
			std::vector<cv::Point2f> img_point_back_H;
			auto Affine = cv::Affine3d(rotMat_back, Matx31d2Vec3d(tvec_back));
    		cv::fisheye::projectPoints(std::vector<cv::Point3f>(1, cv::Point3d(global_point_back_H.x, global_point_back_H.y, global_point_back_H.z)), img_point_back_H, Affine, intrinsic_matrix_back, distortion_coeffs_back);
			auto x_back = img_point_back_H.front().x;
			auto y_back = img_point_back_H.front().y;
			auto u_back = x_back / WIDTH;
			auto v_back = (HEIGHT-y_back) / HEIGHT;
			vertices[7].push_back(x_world_H[i]/scale);
			vertices[7].push_back(y_world_H[i]/scale);
			vertices[7].push_back(z_world_H[i]/scale);
			vertices_size[7] += 3;
			vertices[7].push_back(u_back);
			vertices[7].push_back(v_back);

			//right
			global_point_right_H.x = x_origin_right-x_world_H[i];
			global_point_right_H.y = z_origin_right-z_world_H[i];
			global_point_right_H.z = -(y_world_H[i] - scale*min_y);
			std::vector<cv::Point2f> img_point_right_H;
			auto Affine2 = cv::Affine3d(rotMat_right, Matx31d2Vec3d(tvec_right));
    		cv::fisheye::projectPoints(std::vector<cv::Point3f>(1, cv::Point3d(global_point_right_H.x, global_point_right_H.y, global_point_right_H.z)), img_point_right_H, Affine2, intrinsic_matrix_right, distortion_coeffs_right);
			auto x_right = img_point_right_H.front().x;
			auto y_right = img_point_right_H.front().y;
			auto u_right = x_right / WIDTH;
			auto v_right = (HEIGHT-y_right) / HEIGHT;
			vertices[7].push_back(u_right);
			vertices[7].push_back(v_right);

			//融合weight
			float theta  =atan(abs((x_world_H[i]-x_D)/(z_world_H[i]-z_D)));
			float mixValue = 2*theta / PI;
			vertices[7].push_back(mixValue);
		}

		/*
			generate indices by y-order
        */
        idx_min_y -= offset_idx_min_y;
        
        int32 last_vert_A = vertices_size[0] / _num_vertices;
        int32 last_vert_B = vertices_size[1] / _num_vertices;
        int32 last_vert_C = vertices_size[2] / _num_vertices;
        int32 last_vert_D = vertices_size[3] / _num_vertices;
        int32 last_vert_E = vertices_size[4] / _num_vertices;
        int32 last_vert_F = vertices_size[5] / _num_vertices;
        int32 last_vert_G = vertices_size[6] / _num_vertices;
        int32 last_vert_H = vertices_size[7] / _num_vertices;
        generate_indices(Region::A, indices[0], grid_size, idx_min_y, last_vert_A);
        generate_indices(Region::B, indices[1], grid_size, idx_min_y, last_vert_B);
        generate_indices(Region::C, indices[2], grid_size, idx_min_y, last_vert_C);
        generate_indices(Region::D, indices[3], grid_size, idx_min_y, last_vert_D);
        generate_indices(Region::E, indices[4], grid_size, idx_min_y, last_vert_E);
        generate_indices(Region::F, indices[5], grid_size, idx_min_y, last_vert_F);
        generate_indices(Region::G, indices[6], grid_size, idx_min_y, last_vert_G);
        generate_indices(Region::H, indices[7], grid_size, idx_min_y, last_vert_H);

		fs_read_front.release();
		fs_read_left.release();
		fs_read_back.release();
		fs_read_right.release();
		
		return true;
	}

private:
	void generate_indices(std::vector<uint>& indices, const uint grid_size, const uint idx_min_y, const int32 last_vert) {
		bool oddRow = false;
		for (uint y = 0; y < grid_size - 1; ++y) {
			if (!oddRow) // even rows: y == 0, y == 2; and so on
			{
				for (uint x = 0; x < grid_size; ++x)
				{
					auto current = y * grid_size + x;
					auto next = (y + 1) * grid_size + x;
					/* change order when change disk to elliptic paraboloid */
					if (y == idx_min_y && x == 0) {
						std::swap(current, next);
						indices.push_back(current - grid_size);
						indices.push_back(next);
						indices.push_back(current);
						continue;
					}
					if (set_hole && (current >= last_vert || next >= last_vert))
						continue;
					indices.push_back(current);
					indices.push_back(next);
				}
			}
			else
			{
				for (int x = grid_size - 1; x >= 0; --x)
				{
					auto current = (y + 1) * grid_size + x;
					auto prev = y * grid_size + x;
					/* change order when change disk to elliptic paraboloid */
					if (y == idx_min_y && x == grid_size - 1) {
						indices.push_back(current - grid_size);
						indices.push_back(current);
						indices.push_back(prev);
						continue;
					}
					if (set_hole && (current >= last_vert || prev >= last_vert))
						continue;
					indices.push_back(current);
					indices.push_back(prev);
				}
			}
			oddRow = !oddRow;
		}
	}

	void generate_indices(Region region,std::vector<uint>& indices, const uint grid_size, const uint idx_min_y, const int32 last_vert)
	{
		bool oddRow = false;
        int grid_size_i = 0;

        int r = -1;
        switch (region)
        {
        case Region::A:
                r = 0;
                break;
        case Region::B:
                r = 1;
                break;
        case Region::C:
                r = 2;
                break;
        case Region::D:
                r = 3;
                break;
        case Region::E:
                r = 4;
                break;
        case Region::F:
                r = 5;
                break;
        case Region::G:
                r = 6;
                break;
        case Region::H:
                r = 7;
                break;
        default:
                break;
        }

        for (uint y = 0; y < grid_size - 1; ++y)
        {
                if (!oddRow) // even rows: y == 0, y == 2; and so on
                {
                        // for (uint x = 0; x < grid_size; ++x)
                        for (uint x = 0; x < num_vertices[r][y]; ++x)
                        {
                                // auto current = y * grid_size + x;
                                // auto next = (y + 1) * grid_size + x;
                                auto current = grid_size_i + x;
                                auto next = grid_size_i + x + num_vertices[r][y];
                                /* change order when change disk to elliptic paraboloid */
                                if (y == idx_min_y && x == 0)
                                {
                                        std::swap(current, next);
                                        indices.push_back(current - grid_size);
                                        indices.push_back(next);
                                        indices.push_back(current);
                                        continue;
                                }
                                if (set_hole && (current >= last_vert || next >= last_vert))
                                        continue;
                                indices.push_back(current);
                                indices.push_back(next);
                        }
                }
                else
                {
                        // for (int x = grid_size - 1; x >= 0; --x)
                        for (int x = num_vertices[r][y] - 1; x >= 0; --x)

                        {
                                // auto current = (y + 1) * grid_size + x;
                                // auto prev = y * grid_size + x;
                                auto current = grid_size_i + x + num_vertices[r][y];
                                auto prev = grid_size_i + x;
                                /* change order when change disk to elliptic paraboloid */
                                if (y == idx_min_y && x == grid_size - 1)
                                {
                                        indices.push_back(current - grid_size);
                                        indices.push_back(current);
                                        indices.push_back(prev);
                                        continue;
                                }
                                if (set_hole && (current >= last_vert || prev >= last_vert))
                                        continue;
                                indices.push_back(current);
                                indices.push_back(prev);
                        }
                }
                oddRow = !oddRow;
                grid_size_i = grid_size_i + num_vertices[r][y];
        }
	}

	// compare inner radius and outer radius
	bool lt_radius(const float x, const float z, const float radius) {
		auto r1 = pow((x - cen[0]), 2);
		auto r2 = pow((z - cen[2]), 2);
		auto lt = ((r1 + r2) <= pow(radius, 2));
		return lt;
	}

	bool gt_radius(const float x, const float z, const float radius) {
		auto r1 = pow((x - cen[0]), 2);
		auto r2 = pow((z - cen[2]), 2);
		auto gt = ((r1 + r2) > pow(radius, 2));
		return gt;
	}
};

class PartitionBowl
{
private:
	typedef std::tuple< meshgen::mesh_grid<float, 0, 2>, meshgen::mesh_grid<float, 1, 2>> grid_type;
	constexpr static float def_cen[3]{ 0.f }; // for default value pass to constructor - argument center 
	constexpr static float PI = 3.14159265359f;
	constexpr static auto epsilon = std::numeric_limits<float>::epsilon();
	constexpr static int32 _num_vertices = 3; // x, y, z

private:
	float cen[3];
	float inner_rad;
	float rad;
	float param_a, param_b, param_c;
	float hole_rad;
	bool set_hole = false;
	bool useUV = false;

public:
	PartitionBowl(const float inner_radius, const float radius, const float a, const float b, const float c, const float center[3] = def_cen)
		: inner_rad(inner_radius), rad(radius), param_a(a), param_b(b), param_c(c), hole_rad(0.f)
	{
		cen[0] = center[0];
		cen[1] = center[1];
		cen[2] = center[2];
	}

	bool generate_mesh(const uint part_nums, const float max_size_vert, std::vector<std::vector<float>>& vertices, std::vector<std::vector<uint>>& indices)
	{
		set_hole = false;
		useUV = false;
		return generate_mesh_(part_nums, max_size_vert, vertices, indices);
	}

	bool generate_mesh_uv(const uint part_nums, const float max_size_vert, std::vector<std::vector<float>>& vertices, std::vector<std::vector<uint>>& indices)
	{
		set_hole = false;
		useUV = true;
		return generate_mesh_(part_nums, max_size_vert, vertices, indices);
	}

protected:
	bool generate_mesh_(const uint part_nums, const float max_size_vert, std::vector<std::vector<float>>& vertices, std::vector<std::vector<uint>>& indices)
	{
		if (fabs(param_a) <= epsilon || fabs(param_b) <= epsilon || fabs(param_c) <= epsilon)
			return false;
		if (rad <= 0.f || inner_rad <= 0.f)
			return false;
		if (set_hole && hole_rad <= 0.f)
			return false;
		if (part_nums <= 1)
			return false;
		auto a = param_a;
		auto b = param_b;
		auto c = param_c;

		vertices = std::move(std::vector<std::vector<float>>(part_nums));

		indices = std::move(std::vector<std::vector<uint>>(part_nums));

		float step_size = (2 * PI) / part_nums;

		/*
			prepare grid mesh
		*/
		// texture coordinates generate (u, v) [0, 1]
		std::vector<float> texture_u = meshgen::linspace(0.0f, 1.f, max_size_vert);
		auto texture_v = texture_u;

		std::vector<grid_type> mesh_pairs;
		auto r = meshgen::linspace(0.0f, rad, max_size_vert); 
		for (auto i = 0, next = 1; i < part_nums; i++, next += 1) {
			auto theta = meshgen::linspace(i * step_size, next * step_size, max_size_vert);
			mesh_pairs.push_back(meshgen::meshgrid(r, theta));
		}
		 
		std::vector<std::vector<float>> x_grid(part_nums);
		std::vector<std::vector<float>> y_grid(part_nums);
		std::vector<std::vector<float>> z_grid(part_nums);

		size_t grid_size = std::get<0>(mesh_pairs[0]).size();

		// Convert to rectangular coordinates
		for (auto k = 0; k < part_nums; ++k) {
			auto R = std::get<0>(mesh_pairs[k]);
			auto THETA = std::get<1>(mesh_pairs[k]);
			for (int i = 0; i < grid_size; ++i) {
				for (int j = 0; j < grid_size; ++j) {
					auto x = R(i, j) * cos(THETA(i, j));
					auto z = R(i, j) * sin(THETA(i, j));
					auto y = c * (pow((x / a), 2) + pow((z / b), 2));
					x_grid[k].push_back(x);
					z_grid[k].push_back(z);
					y_grid[k].push_back(y);
				}
			}
		}
		
		/*
			find start level
		*/
		auto min_y = 0.f;
		auto idx_min_y = 0u;
		for (int i = 0; i < grid_size; ++i) {
			for (int j = 0; j < grid_size; ++j) {
				auto x = x_grid[0][j + i * grid_size];
				auto z = z_grid[0][j + i * grid_size];
				if (lt_radius(x, z, inner_rad)) { // check level of paraboloid
					min_y = y_grid[0][j + i * grid_size];
					idx_min_y = i;
					break;
				}
			}
		}	

		/*
			generate mesh vertices for disk and elliptic paraboloid
		*/
		auto half_grid = grid_size / 2;
		for (auto k = 0; k < part_nums; ++k) {
			for (int i = 0; i < grid_size; ++i) {
				for (int j = 0; j < grid_size; ++j) {
					auto x = x_grid[k][j + i * grid_size];
					auto z = z_grid[k][j + i * grid_size];

					if (set_hole) { // check hole inside disk
						auto skip = lt_radius(x, z, hole_rad);
						if (skip)
							continue;
					}

					auto y = min_y;
					if (gt_radius(x, z, inner_rad)) // check level of paraboloid
						y = y_grid[k][j + i * grid_size];
				
					vertices[k].push_back(x + cen[0]);
					vertices[k].push_back(y + cen[1]);
					vertices[k].push_back(z + cen[2]);


					if (useUV) { // texture coordinates
						auto u = texture_u[j];
						auto v = texture_v[i];
						if (j == 0 && i == 0)
							u = texture_u[half_grid];
				
						vertices[k].push_back(u);
						vertices[k].push_back(v);
					}
				}
			}
		}
		
		/*
			generate indices by y-order
		*/
		
		for (auto i = 0; i < part_nums; ++i) {
			bool oddRow = false;
			for (uint y = 0; y < grid_size-1; ++y){
				
				if (!oddRow) // even rows: y == 0, y == 2; and so on
				{
					for (uint x = 0; x < grid_size; ++x)
					{
						auto current = y * grid_size + x;
						auto next = (y + 1) * grid_size + x;
						/* change order when change disk to elliptic paraboloid */
						if (y == idx_min_y && x == 0){
							std::swap(current, next);
							indices[i].push_back(next);
							indices[i].push_back(current);
							indices[i].push_back(current - grid_size);
							continue;
						}
						indices[i].push_back(current);
						indices[i].push_back(next);
					}
				}
				else
				{
					for (int x = grid_size-1; x >= 0; --x)
					{
						auto current = (y + 1) * grid_size + x;
						auto prev = y * grid_size + x;
						/* change order when change disk to elliptic paraboloid */
						if (y == idx_min_y && x == grid_size - 1) {
							std::swap(current, prev);
							indices[i].push_back(current);
							indices[i].push_back(prev);
							indices[i].push_back(prev-grid_size);
							continue;
						}
						indices[i].push_back(current);
						indices[i].push_back(prev);
						
					}
				}
				oddRow = !oddRow;
			}
		}
		
		return true;
	}

private:
	// compare inner radius and outer radius
	bool lt_radius(const float x, const float z, const float radius) {
		auto r1 = pow((x - cen[0]), 2);
		auto r2 = pow((z - cen[2]), 2);
		auto lt = ((r1 + r2) <= pow(radius, 2));
		return lt;
	}

	bool gt_radius(const float x, const float z, const float radius) {
		auto r1 = pow((x - cen[0]), 2);
		auto r2 = pow((z - cen[2]), 2);
		auto gt = ((r1 + r2) > pow(radius, 2));
		return gt;
	}
};
